#include <trie.h>
//Node Methods

node::node(){

}
node::node(char data){


}


node::~node(){


}
//trie Private Methods

 void trie::destroy(){

 }

 void trie::insert(){

 }

 *node trie::search(){

 }

//trie Public Methods

trie::trie():root(new node(' ')){

}

trie::~trie(){

}

void trie::insert(){

}

*node trie::search(){

}